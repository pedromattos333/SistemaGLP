package com.example.alunos.sistemaglp.control;

public class LoginControl {
}
