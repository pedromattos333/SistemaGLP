package com.example.alunos.sistemaglp.dao;

public class LoginDao {
}
