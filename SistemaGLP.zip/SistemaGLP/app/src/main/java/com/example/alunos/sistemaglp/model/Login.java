package com.example.alunos.sistemaglp.model;

import java.io.Serializable;

public class Login implements Serializable {
    private String login;
    private String senha;
}
