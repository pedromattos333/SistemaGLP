package com.example.alunos.sistemaglp.model;

import java.io.Serializable;

public class Relatorio implements Serializable {

}
